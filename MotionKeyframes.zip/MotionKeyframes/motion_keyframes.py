import os 
try:
    import bpy 
except:
    print('Please run this file in blender.')

from pathlib import Path
import numpy as np
from . import data_utils
import mathutils
import math
from bpy_extras.io_utils import (
    axis_conversion,
    ImportHelper,
    ExportHelper
)
from bpy.props import (BoolProperty,
                       FloatProperty,
                       StringProperty,
                       IntProperty,
                       EnumProperty,
                       CollectionProperty)


class MotionKeyframesImporter(bpy.types.Operator, ImportHelper):
    bl_idname = "import_anim.motion_keyframes"
    bl_label = "Import keyframes"
    bl_options = {'PRESET', 'UNDO'}

    filename_ext = ".npz"

    filter_glob: StringProperty(default="*.npz", options={'HIDDEN'})

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")

    scale_setting: FloatProperty(
            name="Scale",
            description="Scale the skeleton by this value",
            min=0.0, max=100.0,
            soft_min=0.0, soft_max=1000.0,
            default=1.0
    )

    axis_forward_setting: EnumProperty(
            name="Forward Axis",
            items=(('X', "X", ""),
                   ('Y', "Y", ""),
                   ('Z', "Z", ""),
                   ('NEGATIVE_X', "-X", ""),
                   ('NEGATIVE_Y', "-Y", ""),
                   ('NEGATIVE_Z', "-Z", ""),
                   ),
            default='X')
            
    axis_up_setting: EnumProperty(
            name="Up",
            items=(('X', "X", ""),
                   ('Y', "Y", ""),
                   ('Z', "Z", ""),
                   ('NEGATIVE_X', "-X", ""),
                   ('NEGATIVE_Y', "-Y", ""),
                   ('NEGATIVE_Z', "-Z", ""),
                   ),
            default='Y')

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False  # No animation.\

        box = layout.box()
        box.label(text="Transform", icon='OBJECT_DATA')
        col = box.column()
        col.prop(self, "scale_setting")
        col.prop(self, "axis_forward_setting")
        col.prop(self, "axis_up_setting")
    
    def execute(self, context):
        parents = [-1, 0, 1, 2, 3, 0, 5, 6, 7, 0, 9, 10, 11, 12, 11, 14, 15, 16, 11, 18, 19, 20]
        fp = Path(self.filepath)
        if fp.suffix == '.npz':
            global_matrix = axis_conversion(from_forward=self.axis_forward_setting, from_up=self.axis_up_setting).to_4x4()

            data = np.load(str(fp))
            rotations = data['rotations']
            rotations = data_utils.matrix6D_to_9D(rotations)
            l_positions = data['l_positions'] * self.scale_setting
            keyframes = data['keyframes'].tolist()
            collection_name = fp.stem
            collection = bpy.data.collections.new(collection_name)
            bpy.context.scene.collection.children.link(collection)
            view_layer = bpy.context.view_layer
            view_layer.active_layer_collection = view_layer.layer_collection.children[collection.name]

            # draw traj
            traj = data['g_positions'][:, 0] * self.scale_setting
            curve_data = bpy.data.curves.new('traj', type='CURVE')
            curve_data.dimensions = '3D'
            curve_obj = bpy.data.objects.new('trajObj', curve_data)
            bpy.context.collection.objects.link(curve_obj)
            polyline = curve_data.splines.new('POLY')

            for i in range(0, len(traj)):
                if traj[i, 0] == traj[i, 1] == traj[i, 2] == 0:
                    continue
                polyline.points[-1].co = (traj[i, 0], traj[i, 1], traj[i, 2], 1)
                if i + 1 < len(traj):
                    polyline.points.add(1)
            print(polyline.points)
            curve_obj.matrix_world = global_matrix
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)

            for f_n in keyframes:
                armature = self.create_keyframe(parents, rotations[f_n], l_positions[f_n], f'frame_{f_n}', global_matrix)
        return {'FINISHED'}

    
    def create_keyframe(self, parents, rotation, l_position, armature_name, global_matrix):
        joint_num = len(parents)
        arm_data = bpy.data.armatures.new(armature_name)
        arm_ob = bpy.data.objects.new(armature_name, arm_data)

        bpy.context.collection.objects.link(arm_ob)

        arm_ob.select_set(True)
        bpy.context.view_layer.objects.active = arm_ob
        bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
        bpy.ops.object.mode_set(mode='EDIT', toggle=False)

        default_bone = arm_data.edit_bones.get("Bone")
        if default_bone:
            arm_data.edit_bones.remove(default_bone)

        joint_list = []
        new_bone = arm_data.edit_bones.new(f'joint_0')
        new_bone.head = l_position[0]
        joint_list = [{'bone': new_bone, 'parent': None, 'children': []}]

        for i in range(1, joint_num):
            new_bone = arm_data.edit_bones.new(f'joint_{i}')
            parent = parents[i]

            new_bone.parent = joint_list[parent]['bone']
            head = [joint_list[parent]['bone'].head[j] + l_position[i, j] for j in range(3)]

            new_bone.head = head
            joint = {'bone': new_bone, 'parent': joint_list[parent] if parent != -1 else None, 'children': []}
            joint_list[parent]['children'].append(joint)
            joint_list.append(joint)

        for joint in joint_list:
            offset = mathutils.Vector([0.0, 0.0, 0.0])
            for child in joint['children']:
                offset = offset + child['bone'].head
            if len(joint['children']) > 0:
                joint['bone'].tail = offset / len(joint['children'])
            else:
                joint['bone'].tail = joint['bone'].head + mathutils.Vector([0.0, self.scale_setting / 10, 0.0])

        bpy.ops.object.mode_set(mode='POSE')

        for i in range(joint_num):
            joint_name = f'joint_{i}'
            if joint_list[i]['children'] == []: continue
            pose_bone = arm_ob.pose.bones[joint_name]
            
            bone_rest_matrix = arm_data.bones[joint_name].matrix_local.to_3x3()
            bone_rest_matrix_inv = mathutils.Matrix(bone_rest_matrix)
            bone_rest_matrix_inv.invert()
            bone_rest_matrix_inv.resize_4x4()
            bone_rest_matrix.resize_4x4()
            
            pose_bone.rotation_mode = 'XYZ'
            matrix = mathutils.Matrix(rotation[i]).to_4x4()
            matrix = bone_rest_matrix_inv @ matrix @ bone_rest_matrix
            pose_bone.rotation_euler = matrix.to_euler()

        bpy.ops.object.mode_set(mode='OBJECT')
        arm_ob.matrix_world = global_matrix
        bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
        return arm_ob
    

class MotionKeyframesExporter(bpy.types.Operator, ExportHelper):
    bl_idname = "export_anim.motion_keyframes"
    bl_label = "EXport keyframes"

    filename_ext = ".npz"
    filter_glob: StringProperty(
        default="*.npz",
        options={'HIDDEN'},
    )

    scale_setting: FloatProperty(
        name="Scale",
        description="Scale the BVH by this value",
        min=0.0001, max=1000000.0,
        soft_min=0.001, soft_max=100.0,
        default=1.0,
    )

    axis_forward_setting: EnumProperty(
            name="Forward Axis",
            items=(('X', "X", ""),
                   ('Y', "Y", ""),
                   ('Z', "Z", ""),
                   ('NEGATIVE_X', "-X", ""),
                   ('NEGATIVE_Y', "-Y", ""),
                   ('NEGATIVE_Z', "-Z", ""),
                   ),
            default='X')
            
    axis_up_setting: EnumProperty(
            name="Up",
            items=(('X', "X", ""),
                   ('Y', "Y", ""),
                   ('Z', "Z", ""),
                   ('NEGATIVE_X', "-X", ""),
                   ('NEGATIVE_Y', "-Y", ""),
                   ('NEGATIVE_Z', "-Z", ""),
                   ),
            default='Y')
    
    motion_length: IntProperty(
        name='Motion Length',
        min=10, max=500,
        default=219
    )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False  # No animation.\

        box = layout.box()
        box.label(text="Transform", icon='OBJECT_DATA')
        col = box.column()
        col.prop(self, "scale_setting")
        col.prop(self, "axis_forward_setting")
        col.prop(self, "axis_up_setting")
    
    @classmethod
    def poll(cls, context):
        collection = context.collection
        for obj in collection.objects:
            if obj.type not in  ["ARMATURE", "CURVE", "EMPTY"]:
                return False
        return True
    
    def execute(self, context):
        collection = context.collection

        arm_example = None
        for obj in collection.objects:
            if obj.name.startswith('frame_'):
                arm_example = obj.data
        joint_num = len(arm_example.bones)
        rotations = np.zeros((self.motion_length, joint_num, 6))
        l_positions = np.zeros((self.motion_length, joint_num, 3))
        keyframes = []
        parents = []
        for bone in arm_example.bones:
            if bone.parent:
                parents.append(arm_example.bones.find(bone.parent.name))
            else:
                parents.append(-1)
        parents = np.array(parents)

        global_matrix = axis_conversion(from_forward=self.axis_forward_setting, from_up=self.axis_up_setting)
        global_matrix_inv = mathutils.Matrix(global_matrix)
        global_matrix_inv.invert()

        hint_mask = np.zeros((self.motion_length, joint_num, 1))
        hint = np.zeros((self.motion_length, joint_num, 3))
        for arm_ob in collection.objects:
            if arm_ob.name.startswith('frame_'):
                bpy.context.view_layer.objects.active = arm_ob
                arm_ob.select_set(True)
                bpy.ops.object.mode_set(mode="EDIT")
                arm_data = arm_ob.data
                f_n = arm_ob.name.split('_')[-1]
                f_n = int(f_n.split('.')[0])
                keyframes.append(f_n)

                for i, bone in enumerate(arm_data.bones):
                    pose_bone = arm_ob.pose.bones[bone.name]
                    edit_bone = arm_data.edit_bones[bone.name]
                    if bone.parent is None:
                        offset = pose_bone.matrix.to_translation()
                    else:
                        offset = edit_bone.head - edit_bone.parent.head
                    offset = global_matrix_inv @ offset
                    
                    l_positions[f_n, i] = np.array(offset) * self.scale_setting
                    bone_rest_matrix = bone.matrix_local.to_3x3()
                    bone_rest_matrix = global_matrix_inv @ bone_rest_matrix
                    bone_rest_matrix_inv = mathutils.Matrix(bone_rest_matrix)
                    bone_rest_matrix_inv.invert()

                    matrix = pose_bone.rotation_euler.to_matrix()
                    matrix = (bone_rest_matrix @ matrix @ bone_rest_matrix_inv)
                    rot6d = data_utils.matrix9D_to_6D(np.array(matrix)[None])
                    rotations[f_n, i] = rot6d
            elif arm_ob.name.startswith('trajObj'):
                bpy.context.view_layer.objects.active = arm_ob
                arm_ob.select_set(True)
                bpy.ops.object.mode_set(mode="EDIT")
                arm_data = arm_ob.data
                traj = []
                spline = arm_data.splines[0]
                for spline in arm_data.splines:
                    print(len(spline.points))
                    for point in spline.points:
                        traj.append(point.co[:3])
                traj = np.array(traj)
                g_positions = np.zeros((self.motion_length, joint_num, 3))
                for i in range(len(traj)):
                    g_positions[i, 0] = traj[i] / self.scale_setting
            elif arm_ob.name.startswith('Control'):
                joint_index = arm_ob['joint_index']
                frame = arm_ob['frame']
                hint_mask[frame, joint_index] = 1
                tmp_global_matrix_inv = np.array(global_matrix_inv)
                hint[frame, joint_index] = arm_ob.location
                hint = np.matmul(tmp_global_matrix_inv[None, None], hint[..., None])[..., 0]
                print(hint[frame, joint_index])
            bpy.ops.object.mode_set(mode="OBJECT")
        np.savez(self.filepath, rotations=rotations, l_positions=l_positions, keyframes=np.array(keyframes), g_positions=g_positions,
                 hint_mask=hint_mask, hint=hint)
        return {"FINISHED"}


def menu_func_import(self, context):
    self.layout.operator(MotionKeyframesImporter.bl_idname, text="Motion Keyframes (.npz)")

def menu_func_export(self, context):
    self.layout.operator(MotionKeyframesExporter.bl_idname, text="Motion Keyframes (.npz)")


def register():
    bpy.utils.register_class(MotionKeyframesImporter)
    bpy.utils.register_class(MotionKeyframesExporter)

    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)

def unregister():
    bpy.utils.unregister_class(MotionKeyframesImporter)
    bpy.utils.unregister_class(MotionKeyframesExporter)

    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)

if __name__ == "__main__":
    unregister()
    register()