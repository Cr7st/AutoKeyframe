bl_info = {
    "name": "Motion Keyframes Tool",
    "blender": (3, 6, 0),
    "category": "Import-Export",
    "version": (1, 0, 0),
    "author": "Bowen Zheng",
    "description": "Creates an Armature based on offset and rotation data from a npz file, and save it back after editing",
    "location": "File > Import-Export",
}


import bpy
import logging
from . import motion_keyframes, prompt_saver


def register():
    motion_keyframes.register()
    prompt_saver.register()


def unregister():
    motion_keyframes.unregister()
    prompt_saver.unregister()

if __name__ == "__main__":
    register()