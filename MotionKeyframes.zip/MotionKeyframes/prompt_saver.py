import bpy
from bpy_extras.io_utils import (
    axis_conversion,
    ImportHelper,
    ExportHelper
)
from bpy.props import (BoolProperty,
                       FloatProperty,
                       StringProperty,
                       IntProperty,
                       EnumProperty,
                       CollectionProperty)
import numpy as np
import mathutils


class FrameCountItem(bpy.types.PropertyGroup):
    frame_count: bpy.props.IntProperty(
        name="Frame Count",
        default=1,
        min=1,
        description="Number of frames between this and the next Bezier point"
    )
    is_keyframe: bpy.props.BoolProperty(
        name="Is Keyframe",
        default=False,
        description="Whether this frame count is a keyframe"
    )


class CurveInterpolator:
    @staticmethod
    def bezier_interpolation(p0, p1, p2, p3, t):
        return (1 - t) ** 3 * p0 + 3 * (1 - t) ** 2 * t * p1 + 3 * (1 - t) * t ** 2 * p2 + t ** 3 * p3

    @staticmethod
    def linear_interpolation(p0, p1, t):
        return p0 + (p1 - p0) * t
    
    @staticmethod
    def interpolate(curve_obj, frame_counts):
        curve = curve_obj.data
        interpolated_points = []
        for spl in curve.splines:
            if spl.type == 'BEZIER':
                points = spl.bezier_points
                count = len(points) - 1
                for i in range(count):
                    if i == 0:
                        interpolated_points.append(points[count - i].co)
                    start_point = points[count - i]
                    end_point = points[count - i - 1]
                    print(f'start_point: {start_point.co}, end_point: {end_point.co}')
                    frame_count = frame_counts[i].frame_count if i < len(frame_counts) else 1
                    num_added = 0
                    for frame in range(1, frame_count + 1):
                        t = frame / frame_count
                        interpolated_coord = CurveInterpolator.bezier_interpolation(start_point.co, start_point.handle_left, end_point.handle_right, end_point.co, t)
                        interpolated_points.append(interpolated_coord)
                        num_added += 1
                    print('num_added:', num_added)
            elif spl.type == 'POLY':
                points = spl.points
                count = len(points) - 1
                for i in range(count):
                    if i == 0:
                        interpolated_points.append(points[i].co)
                    start_point = points[i]
                    end_point = points[i + 1]
                    frame_count = frame_counts[i].frame_count if i < len(frame_counts) else 1
                    for frame in range(1, frame_count + 1):
                        t = frame / frame_count
                        interpolated_coord = CurveInterpolator.linear_interpolation(start_point.co, end_point.co, t)
                        interpolated_points.append(interpolated_coord)
        return interpolated_points


class AKDMTrajEditorPanel(bpy.types.Panel):
    bl_label = "Trajectory"
    bl_idname = "OBJECT_PT_akdm_prompt_editor"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'AutoKeyframe'

    def draw(self, context):
        layout = self.layout
        frame_counts = context.scene.frame_counts

        # 显示当前控制点数量
        num_points = len(frame_counts)
        layout.label(text=f"Number of Segments: {num_points}")

        # 添加输入框以设置每个帧数
        for i, item in enumerate(frame_counts):
            row = layout.row()
            row.prop(item, "frame_count", text=f"Frames between seg {i + 1}")
            row.prop(item, "is_keyframe", text="Key")


class CreateControlPointOperator(bpy.types.Operator):
    bl_idname = "object.create_control_point"
    bl_label = "Create Control Point"
    bl_options = {'REGISTER', 'UNDO'}

    frame: bpy.props.IntProperty(name="Frame", default=1, min=0)
    joint_index: bpy.props.IntProperty(name="Joint Index", default=0, min=0)

    def execute(self, context):
        # 创建一个新的 Empty 对象，设置类型为 PLAIN_AXES
        control_point = bpy.data.objects.new("ControlPoint", None)
        control_point.empty_display_type = 'PLAIN_AXES'  # 选择箭头显示
        control_point.empty_display_size = 1.0  # 设置大小

        # 添加自定义属性
        control_point["frame"] = self.frame
        control_point["joint_index"] = self.joint_index

        # 将控制点对象添加到当前场景
        bpy.context.collection.objects.link(control_point)

        # 输出到控制台
        self.report({'INFO'}, f'Created Control Point at Frame {self.frame} for Joint {self.joint_index}')
        
        return {'FINISHED'}


class ControlPointPanel(bpy.types.Panel):
    bl_label = "Control Point Creator"
    bl_idname = "OBJECT_PT_control_point_creator"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'AutoKeyframe'

    def draw(self, context):
        layout = self.layout

        # 添加输入字段
        layout.prop(context.scene, "control_point_frame")
        layout.prop(context.scene, "control_point_joint_index")

        # 添加创建按钮
        layout.operator(CreateControlPointOperator.bl_idname, text="Create Control Point")


class PromptExporter(bpy.types.Operator, ExportHelper):
    bl_idname = "autokeyframe.export_prompt"
    bl_label = "Export Prompt"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".npz"
    filter_glob: StringProperty(
        default="*.npz",
        options={'HIDDEN'},
    )

    scale_setting: FloatProperty(
        name="Scale",
        description="Scale the BVH by this value",
        min=0.0001, max=1000000.0,
        soft_min=0.001, soft_max=100.0,
        default=1.0,
    )

    axis_forward_setting: EnumProperty(
            name="Forward Axis",
            items=(('X', "X", ""),
                   ('Y', "Y", ""),
                   ('Z', "Z", ""),
                   ('NEGATIVE_X', "-X", ""),
                   ('NEGATIVE_Y', "-Y", ""),
                   ('NEGATIVE_Z', "-Z", ""),
                   ),
            default='X')
            
    axis_up_setting: EnumProperty(
            name="Up",
            items=(('X', "X", ""),
                   ('Y', "Y", ""),
                   ('Z', "Z", ""),
                   ('NEGATIVE_X', "-X", ""),
                   ('NEGATIVE_Y', "-Y", ""),
                   ('NEGATIVE_Z', "-Z", ""),
                   ),
            default='Y')

    action_setting: EnumProperty(
            name="Action",
            items=(('1', "Aiming", ""),
                   ('2', "Dance", ""),
                   ('3', "Fall and Get Up", ""),
                   ('4', "Fight", ""),
                   ('5', "Ground", ""),
                   ('6', "Jumps", ""),
                   ('7', "Obstacles", ""),
                   ('8', "Run", ""),
                   ('9', "Walk", ""),
                   ),
            default='9')


    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False  # No animation.\
        
        box = layout.box()
        box.label(text="Action", icon='OBJECT_DATA')
        col = box.column()
        col.prop(self, "action_setting")

        box = layout.box()
        box.label(text="Transform", icon='OBJECT_DATA')
        col = box.column()
        col.prop(self, "scale_setting")
        col.prop(self, "axis_forward_setting")
        col.prop(self, "axis_up_setting")

    @classmethod
    def poll(cls, context):
        collection = context.collection
        have_traj = False
        for obj in collection.objects:
            if obj.type == 'CURVE':
                if not have_traj:
                    have_traj = True
                else:
                    raise ValueError("Multiple trajectories detected. Please delete all but one trajectory.")
        return have_traj
    
    def execute(self, context):
        collection = context.collection
        
        for obj in collection.objects:
            if obj.type == 'CURVE':
                curve_obj = obj
                traj = CurveInterpolator.interpolate(curve_obj, context.scene.frame_counts)
                traj = np.array(traj)
        hint = np.zeros((traj.shape[0], 22, 3))
        hint[:, 0] = traj
        for obj in collection.objects:
            if obj.type == 'EMPTY' and 'joint_index' in obj and 'frame' in obj:
                joint_index = obj['joint_index']
                frame = obj['frame']
                hint[frame, joint_index] = obj.location
        
        hint = hint * self.scale_setting
        global_matrix = axis_conversion(from_forward=self.axis_forward_setting, from_up=self.axis_up_setting)
        global_matrix_inv = mathutils.Matrix(global_matrix)
        global_matrix_inv.invert()
        global_matrix_inv = np.array(global_matrix_inv)
        hint = np.matmul(global_matrix_inv[None, None], hint[..., None])[..., 0]

        keyframes = []
        num_frames = 0
        for frame_count in context.scene.frame_counts:
            num_frames += frame_count.frame_count
            if frame_count.is_keyframe:
                keyframes.append(num_frames)
        if num_frames != hint.shape[0] - 1:
            raise ValueError("Number of keyframes does not match number of frames in trajectory")
        if num_frames not in keyframes:
            keyframes.append(num_frames)
        print(keyframes)
        
        np.savez(self.filepath, g_positions=hint, action=np.array([int(self.action_setting)]), keyframes=np.array(keyframes))

        return {"FINISHED"}


def update_frame_counts(scene):
    curve_obj = bpy.context.active_object
    if curve_obj and curve_obj.type == 'CURVE' and not curve_obj.name.startswith("traj"):
        num_points = len(curve_obj.data.splines[0].bezier_points) - 1
        frame_counts = scene.frame_counts
        
        while len(frame_counts) < num_points:
            frame_counts.add()
        
        while len(frame_counts) > num_points:
            if len(frame_counts) > 0:  # 确保集合不为空
                frame_counts.remove(len(frame_counts) - 1)

def menu_func_export_prompt(self, context):
    self.layout.operator(PromptExporter.bl_idname, text="Export AutoKeyframe Prompt")


def register():
    bpy.utils.register_class(FrameCountItem)
    bpy.utils.register_class(AKDMTrajEditorPanel)
    bpy.utils.register_class(CreateControlPointOperator)
    bpy.utils.register_class(ControlPointPanel)
    bpy.types.Scene.control_point_frame = bpy.props.IntProperty(name="Frame", default=1, min=1)
    bpy.types.Scene.control_point_joint_index = bpy.props.IntProperty(name="Joint Index", default=0, min=0)
    bpy.types.Scene.frame_counts = bpy.props.CollectionProperty(type=FrameCountItem)
    bpy.app.handlers.depsgraph_update_post.append(update_frame_counts)
    bpy.utils.register_class(PromptExporter)

    bpy.types.TOPBAR_MT_file_export.append(menu_func_export_prompt)


def unregister():
    bpy.utils.unregister_class(FrameCountItem)
    bpy.utils.unregister_class(AKDMTrajEditorPanel)
    bpy.utils.unregister_class(CreateControlPointOperator)
    bpy.utils.unregister_class(ControlPointPanel)
    del bpy.types.Scene.frame_counts
    bpy.app.handlers.depsgraph_update_post.remove(update_frame_counts)
    bpy.utils.unregister_class(PromptExporter)

    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export_prompt)


if __name__ == "__main__":
    register()