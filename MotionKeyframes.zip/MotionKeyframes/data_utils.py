import numpy as np


def move_start_to_origin(root_trans, frame=0, return_offset=False):
    """
    Move the starting position to origin, while remaining y (height) unchanged.
    :param: root_trans (ndarray): (seq_len, 3)
    :return: ndarray: (seq_len, 3)
    """
    res = root_trans.copy()
    offset = root_trans[None, frame, ::2]
    res[:, ::2] = root_trans[:, ::2] - offset
    if return_offset:
        return res, root_trans[None, frame, ::2]
    else:
        return res


def normalize(array, axis=-1, eps=1e-5):
    """
    Normalize ndarray along given axis.

    Args:
        array (ndarray) N-dimensional array.
        axis (int, optional): Axis. Defaults to -1.
        eps (float, optional): Small value to avoid division by zero.
            Defaults to 1e-5.

    Returns:
        ndarray: Normalized N-dimensional array.
    """
    magnitude = np.linalg.norm(array, axis=axis, keepdims=True)
    magnitude[magnitude < eps] = np.inf
    return array / magnitude


def matrix6D_to_9D(d6: np.float32):
    """
    Converts 6D rotation representation by Zhou et al. [1] to rotation matrix
    using Gram--Schmidt orthogonalization per Section B of [1].
    Args:
        d6: 6D rotation representation, of size (*, 6)

    Returns:
        batch of rotation matrices of size (*, 3, 3)

    [1] Zhou, Y., Barnes, C., Lu, J., Yang, J., & Li, H.
    On the Continuity of Rotation Representations in Neural Networks.
    IEEE Conference on Computer Vision and Pattern Recognition, 2019.
    Retrieved from http://arxiv.org/abs/1812.07035
    """

    d6 = d6.copy()
    a1, a2 = d6[..., :3], d6[..., 3:]
    b1 = normalize(a1, axis=-1)
    b2 = a2 - np.sum(b1 * a2, axis=-1, keepdims=True) * b1
    b2 = normalize(b2, axis=-1)
    b3 = np.cross(b1, b2, axis=-1)
    return np.stack((b1, b2, b3), axis=-2)


def matrix9D_to_6D(matrix: np.float64):
    """
    Converts rotation matrices to 6D rotation representation by Zhou et al. [1]
    by dropping the last row. Note that 6D representation is not unique.
    Args:
        matrix: batch of rotation matrices of size (*, 3, 3)

    Returns:
        6D rotation representation, of size (*, 6)

    [1] Zhou, Y., Barnes, C., Lu, J., Yang, J., & Li, H.
    On the Continuity of Rotation Representations in Neural Networks.
    IEEE Conference on Computer Vision and Pattern Recognition, 2019.
    Retrieved from http://arxiv.org/abs/1812.07035
    """
    batch_dim = matrix.shape[:-2]
    return matrix[..., :2, :].copy().reshape(batch_dim + (6,))

# def matrix6D_to_9D(mat):
#     """
#     Convert 6D rotation representation to 3x3 rotation matrix using
#     Gram-Schmidt orthogonalization.

#     Args:
#         mat (ndarray): Input 6D rotation representation. Shape: (..., 6)

#     Raises:
#         ValueError: Last dimension of mat is not 6.

#     Returns:
#         ndarray: Output rotation matrix. Shape: (..., 3, 3)
#     """
#     if mat.shape[-1] != 6:
#         raise ValueError(
#             "Last two dimension should be 6, got {0}.".format(mat.shape[-1]))

#     mat = mat.copy().reshape(*mat.shape[:-1], 3, -1)

#     # normalize column 0
#     mat[..., 0] = normalize(mat[..., 0], axis=-1)

#     # calculate column 1
#     dot_prod = np.matmul(mat[..., 0][..., None, :], mat[..., 1][..., None]).squeeze(-1)
#     mat[..., 1] -= dot_prod * mat[..., 0]
#     mat[..., 1] = normalize(mat[..., 1], axis=-1)

#     # calculate last column using cross product
#     last_col = np.cross(mat[..., 0:1], mat[..., 1:2],
#                         axisa=-2, axisb=-2, axisc=-2)

#     return np.concatenate([mat, last_col], axis=-1)


# def matrix9D_to_6D(mat):
#     return mat[..., :-1].reshape((*mat.shape[:-2], 6))
